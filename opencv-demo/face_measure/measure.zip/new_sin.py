#!/usr/bin/env python
# coding=utf8

import numpy as np
import cv2
from ccalibration import CCameraCalibration
from cMonocularMeasure import MonocularMeasure

try:
    ros_env = True
    import rospy
except:
    ros_env = False
    print('NO MODULE Named rospy')

images_path_win = 'C:\\Users\\hp\\Desktop\\1280\\circle\\'
# images_path_win = 'C:\\Users\\hp\\Desktop\\1280\\'
images_path_ros = '/home/zq/Desktop/1280/91/'
images_path = images_path_ros   #默认
win_mode = False

if ros_env == True:
    rospy.init_node('demo_mo', anonymous=False)
else:
    images_path = images_path_win
    win_mode = True


#多张图片标定得到相机的内参与畸变向量
mycc = CCameraCalibration()
mycc.monocular_set_calibration_images(images_path, 'monocular.npy', False, 16, 720, 1280, [7,7], 5.0, mode='circle')
mycc.monocular_calibration('monocular.npy', True)
mycc.monocular_print()


mycmm = MonocularMeasure()
#对称圆标定板上圆的行数、列数
monocular_circleSize = [7,7]
monocular_circleCellLen = 5.0 #mm，圆心距


imgpath = 'C:\\Users\\hp\\Desktop\\0.jpg' #测距用的单张标定图像，会标定出该平面上的外参数

#得到该标定图像中标定板上的圆心实际坐标与对应像素坐标
ret_l, world_points, pixel_points = mycmm.findCornersAndWorldPoints(singleImgPath=imgpath, 
                                                chessSize=monocular_circleSize, 
                                                chessCellLen=monocular_circleCellLen, mode='circle')
h, mask = cv2.findHomography( pixel_points, world_points[:,:-1],method=cv2.RANSAC)


p0 = np.array([792, 584, 1], dtype=np.float32).reshape(3,1)
p1 = np.array([863.5, 563,1], dtype=np.float32).reshape(3,1)

#高度变换后, 3.0为标定板厚度
# h_low = -3.0
h_low = 23.9-3
# h_low = 10

A = mycc._monocularParameters["cameraMatrix"]
distCoeff = mycc._monocularParameters["distCoeffs"]

h = mycmm.findHByPnPAndZDiff(A, distCoeff, world_points, pixel_points, zLow=h_low)
################################################

#求世界坐标平面上的齐次坐标，并做归一化(一般可以不用)
pt1 = h @ p0
pt1 = pt1/pt1[-1]

pt2 = h @ p1
pt2 = pt2/pt2[-1]

length = np.math.sqrt(np.sum((pt1-pt2)**2)) #求解两点长度

print('H Matrix : ','\n', h, '\n')
print('source point: ', p0.reshape(-1), p1.reshape(-1))
print('dst point: ', pt1.reshape(-1), pt2.reshape(-1))
print('\nlen: ', length)

