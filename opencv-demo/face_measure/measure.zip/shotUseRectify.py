
# coding=utf8
import numpy as np
from cv2 import CALIB_CB_SYMMETRIC_GRID, cv2
from ccalibration import CCameraCalibration
import os

#运行这个文件得到相机内参与畸变向量，并存储到标定文件
#标点完成后会开启摄像头，可以观察畸变矫正的效果，按 w 保存畸变矫正后的图片，按q退出

#标定图片或者标定文件所在的文件夹
images_path_win = 'C:\\Users\\hp\\Desktop\\1280\\circle\\' 

#畸变矫正后的图片保存路径
rectifySavePath = 'C:\\Users\\hp\\Desktop\\0.jpg'

#----------------------------------------------------------------------------------------------#分割线
try:
    ros_env = True
    import rospy
except:
    ros_env = False
    print('NO MODULE Named rospy')


images_path_ros = '/home/zq/Desktop/1280/91/'   #linux下的
images_path = images_path_ros   #默认为linux系统
win_mode = False

#如果导入ros的相关包失败，则为win系统
if ros_env == True:
    pass
else:
    images_path = images_path_win
    win_mode = True

imgs_list = os.listdir(images_path)
num_sum = 0
for item in imgs_list:
    if len(item.split('.')) >= 2:
        if item.split('.')[-1] == 'jpg':
            num_sum = num_sum + 1
if num_sum < 8:
    print('你的标定板数量过少，请检查')
#初始化相机标定对象
mycc = CCameraCalibration()
mycc.monocular_set_calibration_images(images_path, 'monocular.npy', False, num_sum, 720, 1280, [7,7], 5.0, mode='circle')
# mycc.monocular_set_calibration_images(images_path, 'monocular.npy', False, 10, 720, 1280, [6,8], 6.13, mode='square')
mycc.monocular_calibration('monocular.npy', True)

mycc.monocular_print()

#初始化相机捕获类
cap = 0
if win_mode == True:
    cap = cv2.VideoCapture(1 , cv2.CAP_DSHOW)
else:
    cap = cv2.VideoCapture(0)
cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M','J','P','G'))
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

#在显示的图像中，按下w键保存图像到images_path_win路径之下
#在角点被完全检测到的时候再保存
count = 1
while(True):
    if cap.isOpened() == False:
        print('can not open camera')
        break
    ret, frame = cap.read()
    if ret == False:
        continue
    # print(frame.shape)
    frame = mycc.monocular_remap(frame)
    
    #circle格的行数、列数
    patternSize = (7,7)
    flags = CALIB_CB_SYMMETRIC_GRID #对称的圆网格
    retval, centers	=cv2.findCirclesGrid(frame, patternSize, flags) #检测圆心
    
    image = frame.copy()
  
    if retval:
        print(centers.shape)
        print(centers[0])
    image = cv2.drawChessboardCorners(image, patternSize, centers, retval) #画出角点
  
    cv2.namedWindow("FRAME")
    cv2.imshow('FRAME',frame)
    
    cv2.imshow('detect', image)

    mykey = cv2.waitKey(1)
    if mykey & 0xFF == ord('q'):
        break
    
    if mykey & 0xFF == ord('w'):
        cv2.imwrite(rectifySavePath, frame)
        count+=1
        
# When everything done, release the capture
if ros_env == True:
    pass
cap.release()
cv2.destroyAllWindows()


 